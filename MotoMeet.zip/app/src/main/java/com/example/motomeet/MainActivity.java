package com.example.motomeet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.TableLayout;

import com.example.motomeet.adapter.ViewPagerAdapter;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private Toolbar toolbar;

    ViewPagerAdapter viewPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        addTabs();
    }

    private void init(){

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        viewPager = findViewById(R.id.viewPager);
    }

    private void addTabs(){

        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.baseline_home_24));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.baseline_search_24));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.baseline_add_box_24));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.baseline_favorite_24));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.baseline_favorite_border_24));

        tabLayout.setTabGravity(TabLayout.GRAVITY_CENTER);
        tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);

        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(viewPagerAdapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_home_24);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());

                switch (tab.getPosition()){

                    case 0:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_home_24);
                        break;

                    case 1:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_search_24);
                        break;

                    case 2:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_add_box_24);
                        break;

                    case 3:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_favorite_24);
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                switch (tab.getPosition()){

                    case 0:
                        tabLayout.getTabAt(0).setIcon(R.drawable.outline_home_24);
                        break;

                    case 1:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_search_24);
                        break;

                    case 2:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_add_box_24);
                        break;

                    case 3:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_favorite_border_24);
                        break;

                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                switch (tab.getPosition()){

                    case 0:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_home_24);
                        break;

                    case 1:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_search_24);
                        break;

                    case 2:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_add_box_24);
                        break;

                    case 3:
                        tabLayout.getTabAt(0).setIcon(R.drawable.baseline_favorite_24);
                        break;
                }
            }
        });
    }
}